//package controllers;
//
//import classes.Product;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.fxml.FXML;
//import javafx.scene.control.ComboBox;
//import javafx.scene.control.TableColumn;
//import javafx.scene.control.TableView;
//import javafx.scene.control.TextField;
//import javafx.scene.control.cell.PropertyValueFactory;
//import main.Main;
//
//import java.net.URL;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.ResourceBundle;
//
//public class OrderController {
//    @FXML
//    private TableView<Product> tableView;
//    @FXML private TableColumn<Product, Integer> idColumn;
//    @FXML private TableColumn<Product, String> nameColumn;
//    @FXML private TableColumn<Product, Integer> quantityColumn;
//    @FXML private TableColumn<Product, Float> costPriceColumn;
//    @FXML private TableColumn<Product, Float> sellingPriceColumn;
//    @FXML private TableColumn<Product, Float> grossPriceColumn;
//
//    // text fields in add cat
//    @FXML private TextField nameTextField;
//    @FXML private TextField quantityTextField;
//    @FXML private TextField costTextField;
//    @FXML private TextField categoryTextField;
//    @FXML private TextField sellingTextField;
//
//
//    // combobox
//    @FXML private ComboBox<String> comboBox;
//    @FXML private ComboBox<String> comboBoxType;
//
//    @FXML public static ObservableList<String> categories = FXCollections.observableArrayList(
//            "Beverages", "Bread / Bakery", "Canned / Jarred Goods", "Dairy", "Dry / Baking Goods", "Frozen Goods",
//            "Meat", "Produce", "Cleaners", "Paper Goods", "Personal Care"
//    );
//
//    @FXML public static ObservableList<String> types = FXCollections.observableArrayList("Stacked", "Queued", "List");
//
//
//    // Categories and Structure
//    private Map<String, String> category_ds = new HashMap<String, String>();
//
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle) {
//        idColumn.setCellValueFactory(new PropertyValueFactory<Product, Integer>("id"));
//        nameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
//        quantityColumn.setCellValueFactory(new PropertyValueFactory<Product, Integer>("quantity"));
//        costPriceColumn.setCellValueFactory(new PropertyValueFactory<Product, Float>("cost_price"));
//        sellingPriceColumn.setCellValueFactory(new PropertyValueFactory<Product, Float>("selling_price"));
//        grossPriceColumn.setCellValueFactory(new PropertyValueFactory<Product, Float>("gross_price"));
//
//        // load data from data structures (queues, stacks and lists) for UI
////        int response = Product.getProducts();
////        System.out.println(response);
//        tableView.setItems(Main.inventory.dsToObservableList(0));
//
//        // Category list
//        category_ds.put("Beverages", "Stacks");
//        category_ds.put("Bread / Bakery", "Stacks");
//        category_ds.put("Canned / Jarred Goods", "Stacks");
//        category_ds.put("Dairy", "Stacks");
//        category_ds.put("Dry / Baking Goods", "Stacks");
//        category_ds.put("Frozen Goods", "Stacks");
//        category_ds.put("Meat", "Stacks");
//        category_ds.put("Produce", "Stacks");
//        category_ds.put("Cleaners", "Stacks");
//        category_ds.put("Paper Goods", "Stacks");
//        category_ds.put("Personal Care", "Stacks");
//
//        comboBox.setItems(categories);
//        comboBoxType.setItems(types);
//    }
//}
